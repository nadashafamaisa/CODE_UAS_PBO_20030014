#include <iostream>
using namespace std;
int main()
{
float phi = 3.14;
int jari = 10;
int tinggi = 5;
    cout << "DIKETAHUI:" << endl;
    cout << " phi = " << phi << endl;
    cout << " jari-jari = " << jari << endl;
    cout << " tinggi = " << tinggi << endl << endl;
    cout << "DITANYA:" << endl; 
    cout << "1. Luas Selimut Tabung" << endl;
    cout << "2. Volume Tabung" << endl << endl;
    cout << "PENYELESAIANNYA:" << endl;
    cout << "+---------------------------------+" << endl;
    cout << "|-------LUAS SELIMUT TABUNG-------|" << endl; 
    cout << "| = 2 x phi x jari-jari x tinggi  |" << endl;
    cout << "| = 2 x 3.14 x 10 x 5             |" << endl;
    cout << "| = " << 2*phi*jari*tinggi << endl;
    cout << "+---------------------------------+" << endl << endl;
    cout << "+----------------------------------------+" << endl;
    cout << "|-------------VOLUME TABUNG--------------|" << endl;
    cout << "| = phi x jari-jari x jari-jari x tinggi |" << endl;
    cout << "| = 3.14 x 10 x 10 x 5                   |" << endl;
    cout << "| = " << phi*jari*jari*tinggi << endl;
    cout << "+----------------------------------------+" << endl << endl;
    cout << " NADA SHAFA MAISA (20030014) " << endl;
    return 0;
}
